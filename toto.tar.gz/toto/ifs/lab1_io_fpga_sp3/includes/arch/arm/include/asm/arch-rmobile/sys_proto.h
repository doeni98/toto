/*
 * (C) Copyright 2010
 * Texas Instruments, <www.ti.com>
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef _SYS_PROTO_H_
#define _SYS_PROTO_H_

struct rmobile_sysinfo {
	char *board_string;
};
extern const struct rmobile_sysinfo sysinfo;

#endif
