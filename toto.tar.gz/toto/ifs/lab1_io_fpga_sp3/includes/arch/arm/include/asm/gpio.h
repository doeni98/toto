#include <asm/arch/gpio.h>
#include <asm-generic/gpio.h>
