#ifndef _TEGRA114_POWERGATE_H_
#define _TEGRA114_POWERGATE_H_

#include <asm/arch-tegra/powergate.h>

#endif /* _TEGRA114_POWERGATE_H_ */
