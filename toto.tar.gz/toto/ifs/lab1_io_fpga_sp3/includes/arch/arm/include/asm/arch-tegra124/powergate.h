#ifndef _TEGRA124_POWERGATE_H_
#define _TEGRA124_POWERGATE_H_

#include <asm/arch-tegra/powergate.h>

#endif /* _TEGRA124_POWERGATE_H_ */
