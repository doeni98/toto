/*
 * Copyright (c) 2014-2015 NVIDIA CORPORATION. All rights reserved.
 *
 * SPDX-License-Identifier: GPL-2.0+
 */

#ifndef _TEGRA210_POWERGATE_H_
#define _TEGRA210_POWERGATE_H_

#include <asm/arch-tegra/powergate.h>

#endif /* _TEGRA210_POWERGATE_H_ */
