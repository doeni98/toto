/*
 * (C) Copyright 2010
 * Vipin Kumar, STMicroelectronics, <vipin.kumar@st.com>
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

static inline unsigned long get_macb_pclk_rate(unsigned int dev_id)
{
	return 83000000;
}
