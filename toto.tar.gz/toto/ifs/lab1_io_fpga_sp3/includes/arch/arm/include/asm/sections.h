/*
 * Copyright (c) 2012 The Chromium OS Authors.
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef __ASM_ARM_SECTIONS_H
#define __ASM_ARM_SECTIONS_H

#include <asm-generic/sections.h>

#endif
